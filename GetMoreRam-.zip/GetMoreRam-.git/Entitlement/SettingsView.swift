//
//  SettingsView.swift
//  Entitlement
//
//  Created by s s on 2025/3/14.
//

import SwiftUI
import StosSign

// Small reusable icon badge, used to give settings rows the
// colored-square-icon look (iOS Settings / LiveContainer style).
struct SettingsIconBadge: View {
    let icon: String
    let tint: Color
    
    var body: some View {
        RoundedRectangle(cornerRadius: 7)
            .fill(tint.gradient)
            .frame(width: 28, height: 28)
            .overlay(
                Image(systemName: icon)
                    .foregroundStyle(.white)
                    .font(.system(size: 14, weight: .semibold))
            )
    }
}

struct SettingsView: View {

    @State var email = ""
    @State var teamId = ""
    @StateObject var viewModel : LoginViewModel
    @EnvironmentObject private var sharedModel : SharedModel
    
    @State private var errorShow = false
    @State private var errorInfo = ""
    

    var body: some View {
        NavigationView {
            Form {
                Section {
                    if sharedModel.isLogin {
                        HStack(spacing: 14) {
                            Circle()
                                .fill(LinearGradient(colors: [.blue, .indigo], startPoint: .top, endPoint: .bottom))
                                .frame(width: 50, height: 50)
                                .overlay(
                                    Image(systemName: "person.fill")
                                        .foregroundStyle(.white)
                                        .font(.system(size: 22))
                                )
                            VStack(alignment: .leading, spacing: 3) {
                                Text(email)
                                    .font(.body)
                                Text("Team ID: \(teamId)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                    } else {
                        Button {
                            viewModel.loginModalShow = true
                        } label: {
                            HStack(spacing: 14) {
                                Circle()
                                    .fill(Color.gray.opacity(0.35))
                                    .frame(width: 50, height: 50)
                                    .overlay(
                                        Image(systemName: "person.fill")
                                            .foregroundStyle(.white)
                                            .font(.system(size: 22))
                                    )
                                Text("Sign in")
                                    .foregroundStyle(.primary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                } header: {
                    Text("Account")
                }
                
                Section {
                    HStack(spacing: 12) {
                        SettingsIconBadge(icon: "network", tint: .orange)
                        Text("Anisette Server")
                        Spacer()
                        TextField("", text: $sharedModel.anisetteServerURL)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.secondary)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                }
                
                Section {
                    Button {
                        cleanUp()
                    } label: {
                        HStack(spacing: 12) {
                            SettingsIconBadge(icon: "key.fill", tint: .red)
                            Text("Clean Up Keychain")
                                .foregroundStyle(.red)
                        }
                    }
                } footer: {
                    Text("If something went wrong during signing in, please try to clean up the keychain, reopen the app and try again.")
                }
            }
            .navigationTitle("Settings")
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .alert("Error", isPresented: $errorShow){
            Button("OK".loc, action: {
            })
        } message: {
            Text(errorInfo)
        }
        .sheet(isPresented: $viewModel.loginModalShow) {
            loginModal
        }
    }
    
    var loginModal: some View {
        NavigationView {
            Form {
                Section {
                    TextField("", text: $viewModel.appleID)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .disabled(viewModel.isLoginInProgress)
                } header: {
                    Text("Apple ID")
                }
                Section {
                    SecureField("", text: $viewModel.password)
                        .disabled(viewModel.isLoginInProgress)
                } header: {
                    Text("Password")
                }
                if viewModel.needVerificationCode {
                    Section {
                        TextField("", text: $viewModel.verificationCode)
                    } header: {
                        Text("Verification Code")
                    }
                }
                Section {
                    Button("Continue") {
                        Task{ await loginButtonClicked() }
                    }
                }
                
                Section {
                    Text(viewModel.logs)
                        .font(.system(.subheadline, design: .monospaced))
                } header: {
                    Text("Debugging")
                }
            }
            .navigationTitle("Sign in")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel", role: .cancel) {
                        viewModel.loginModalShow = false
                    }
                }
            }
        }
        .onAppear {
            if let email = Keychain.shared.appleIDEmailAddress, let password = Keychain.shared.appleIDPassword {
                viewModel.appleID = email
                viewModel.password = password
            }
        }
    }
    
    func loginButtonClicked() async {
        do {
            if viewModel.needVerificationCode {
                viewModel.submitVerficationCode()
                return
            }
            
            let result = try await viewModel.authenticate()
            if result {
                viewModel.loginModalShow = false
                email = sharedModel.account!.appleID
                teamId = sharedModel.team!.identifier
            }
            
        } catch {
            errorInfo = error.localizedDescription
            errorShow = true
        }
    }
    
    func cleanUp() {
        Keychain.shared.adiPb = nil
        Keychain.shared.identifier = nil
        Keychain.shared.appleIDPassword = nil
        Keychain.shared.appleIDEmailAddress = nil
    }
    
}
