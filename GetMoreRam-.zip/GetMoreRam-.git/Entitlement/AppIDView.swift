//
//  AppIDView.swift
//  Entitlement
//
//  Created by s s on 2025/3/15.
//
import SwiftUI

// MARK: - Capability catalog

/// A single capability that can be added to an App ID.
/// `id` must match Apple's exact capability identifier string.
struct CapabilityInfo: Identifiable, Hashable {
    let label: String
    let id: String
    let icon: String
    let tint: Color
}

enum CapabilityCatalog {
    // The two "hidden" capabilities this app started with. These aren't
    // exposed in Xcode's Signing & Capabilities UI, but the developer
    // services backend accepts them.
    static let hidden: [CapabilityInfo] = [
        CapabilityInfo(label: "Increased Memory Limit", id: "INCREASED_MEMORY_LIMIT", icon: "memorychip.fill", tint: .blue),
        CapabilityInfo(label: "Extended Virtual Addressing", id: "EXTENDED_VIRTUAL_ADDRESSING", icon: "arrow.left.and.right.square.fill", tint: .purple)
    ]
    
    // Standard capabilities, using the identifier strings Apple's own
    // App Store Connect API documents/accepts (confirmed against Apple's
    // CapabilityType enum). These are normally added through Xcode, but
    // work the same way through this app.
    static let standard: [CapabilityInfo] = [
        CapabilityInfo(label: "iCloud", id: "ICLOUD", icon: "icloud.fill", tint: .blue),
        CapabilityInfo(label: "In-App Purchase", id: "IN_APP_PURCHASE", icon: "cart.fill", tint: .green),
        CapabilityInfo(label: "Game Center", id: "GAME_CENTER", icon: "gamecontroller.fill", tint: .indigo),
        CapabilityInfo(label: "Push Notifications", id: "PUSH_NOTIFICATIONS", icon: "bell.badge.fill", tint: .red),
        CapabilityInfo(label: "Wallet", id: "WALLET", icon: "wallet.pass.fill", tint: .orange),
        CapabilityInfo(label: "Inter-App Audio", id: "INTER_APP_AUDIO", icon: "waveform", tint: .pink),
        CapabilityInfo(label: "Maps", id: "MAPS", icon: "map.fill", tint: .green),
        CapabilityInfo(label: "Associated Domains", id: "ASSOCIATED_DOMAINS", icon: "link", tint: .blue),
        CapabilityInfo(label: "Personal VPN", id: "PERSONAL_VPN", icon: "lock.shield.fill", tint: .gray),
        CapabilityInfo(label: "App Groups", id: "APP_GROUPS", icon: "person.3.fill", tint: .teal),
        CapabilityInfo(label: "HealthKit", id: "HEALTHKIT", icon: "heart.fill", tint: .red),
        CapabilityInfo(label: "HomeKit", id: "HOMEKIT", icon: "house.fill", tint: .orange),
        CapabilityInfo(label: "Wireless Accessory Configuration", id: "WIRELESS_ACCESSORY_CONFIGURATION", icon: "antenna.radiowaves.left.and.right", tint: .blue),
        CapabilityInfo(label: "Apple Pay", id: "APPLE_PAY", icon: "creditcard.fill", tint: .black),
        CapabilityInfo(label: "Data Protection", id: "DATA_PROTECTION", icon: "lock.fill", tint: .gray),
        CapabilityInfo(label: "SiriKit", id: "SIRIKIT", icon: "mic.fill", tint: .purple),
        CapabilityInfo(label: "Network Extensions", id: "NETWORK_EXTENSIONS", icon: "network", tint: .blue),
        CapabilityInfo(label: "Multipath", id: "MULTIPATH", icon: "arrow.triangle.branch", tint: .blue),
        CapabilityInfo(label: "Hotspot", id: "HOT_SPOT", icon: "wifi", tint: .blue),
        CapabilityInfo(label: "NFC Tag Reading", id: "NFC_TAG_READING", icon: "wave.3.right", tint: .blue),
        CapabilityInfo(label: "ClassKit", id: "CLASSKIT", icon: "book.fill", tint: .brown),
        CapabilityInfo(label: "AutoFill Credential Provider", id: "AUTOFILL_CREDENTIAL_PROVIDER", icon: "key.fill", tint: .yellow),
        CapabilityInfo(label: "Access WiFi Information", id: "ACCESS_WIFI_INFORMATION", icon: "wifi.circle.fill", tint: .blue),
        CapabilityInfo(label: "Network Custom Protocol", id: "NETWORK_CUSTOM_PROTOCOL", icon: "network", tint: .gray),
        CapabilityInfo(label: "Low Latency HLS", id: "COREMEDIA_HLS_LOW_LATENCY", icon: "play.tv.fill", tint: .purple),
        CapabilityInfo(label: "System Extension", id: "SYSTEM_EXTENSION_INSTALL", icon: "gearshape.2.fill", tint: .gray),
        CapabilityInfo(label: "User Management", id: "USER_MANAGEMENT", icon: "person.crop.circle.badge.checkmark", tint: .blue),
        CapabilityInfo(label: "Sign in with Apple", id: "APPLE_ID_AUTH", icon: "apple.logo", tint: .black)
    ]
    
    static var all: [CapabilityInfo] { hidden + standard }
}

// MARK: - Add Capability sheet (the "menu")

struct AddCapabilityView: View {
    @ObservedObject var viewModel: AppIDModel
    @Environment(\.dismiss) private var dismiss
    
    @State private var searchText = ""
    @State private var customID = ""
    @State private var isAdding = false
    @State private var errorShow = false
    @State private var errorInfo = ""
    
    private var filtered: [CapabilityInfo] {
        guard !searchText.isEmpty else { return CapabilityCatalog.all }
        return CapabilityCatalog.all.filter {
            $0.label.localizedCaseInsensitiveContains(searchText) ||
            $0.id.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    var body: some View {
        NavigationView {
            List {
                Section {
                    ForEach(filtered) { capability in
                        Button {
                            Task { await add(capability.id) }
                        } label: {
                            HStack(spacing: 14) {
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(capability.tint.gradient)
                                    .frame(width: 30, height: 30)
                                    .overlay(
                                        Image(systemName: capability.icon)
                                            .foregroundStyle(.white)
                                            .font(.system(size: 14, weight: .semibold))
                                    )
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(capability.label)
                                        .foregroundStyle(.primary)
                                    Text(capability.id)
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                if isAdding {
                                    ProgressView()
                                }
                            }
                        }
                        .disabled(isAdding)
                    }
                } header: {
                    Text("Known Capabilities")
                }
                
                Section {
                    TextField("e.g. SOME_CAPABILITY_ID", text: $customID)
                        .autocapitalization(.allCharacters)
                        .disableAutocorrection(true)
                        .disabled(isAdding)
                    Button {
                        Task { await add(customID) }
                    } label: {
                        Text("Add Custom Capability")
                    }
                    .disabled(customID.trimmingCharacters(in: .whitespaces).isEmpty || isAdding)
                } header: {
                    Text("Custom")
                } footer: {
                    Text("Enter any Apple capability identifier exactly as Apple expects it (all caps, underscores). If it doesn't apply to your account or App ID, Apple's server will return an error in the response instead of adding it.")
                }
            }
            .searchable(text: $searchText, prompt: "Search capabilities")
            .navigationTitle("Add Capability")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel", role: .cancel) {
                        dismiss()
                    }
                }
            }
            .alert("Error", isPresented: $errorShow) {
                Button("OK".loc, action: {})
            } message: {
                Text(errorInfo)
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    private func add(_ capabilityID: String) async {
        let trimmed = capabilityID.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmed.isEmpty else { return }
        isAdding = true
        defer { isAdding = false }
        do {
            try await viewModel.addCapability(trimmed)
            dismiss()
        } catch {
            errorInfo = error.localizedDescription
            errorShow = true
        }
    }
}

// MARK: - Capability detail / edit screen

struct AppIDEditView : View {
    @StateObject var viewModel : AppIDModel
    
    @State private var errorShow = false
    @State private var errorInfo = ""
    @State private var showAddCapability = false
    
    var body: some View {
        List {
            Section {
                ForEach(CapabilityCatalog.hidden) { capability in
                    Button {
                        Task { await addCapability(capability.id) }
                    } label: {
                        HStack(spacing: 14) {
                            RoundedRectangle(cornerRadius: 8)
                                .fill(capability.tint.gradient)
                                .frame(width: 30, height: 30)
                                .overlay(
                                    Image(systemName: capability.icon)
                                        .foregroundStyle(.white)
                                        .font(.system(size: 14, weight: .semibold))
                                )
                            Text(capability.label)
                                .foregroundStyle(.primary)
                            Spacer()
                            Image(systemName: "plus.circle")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                
                Button {
                    showAddCapability = true
                } label: {
                    HStack(spacing: 14) {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.secondary.gradient)
                            .frame(width: 30, height: 30)
                            .overlay(
                                Image(systemName: "ellipsis")
                                    .foregroundStyle(.white)
                                    .font(.system(size: 14, weight: .semibold))
                            )
                        Text("More Capabilities…")
                            .foregroundStyle(.primary)
                        Spacer()
                    }
                }
            } header: {
                Text("Capabilities")
            } footer: {
                Text("Adds the entitlement to this App ID on Apple's developer portal. Reinstall the app from SideStore/AltStore afterward for it to take effect.")
            }
            
            if !viewModel.result.isEmpty {
                Section {
                    Text(viewModel.result)
                        .font(.system(.footnote, design: .monospaced))
                        .textSelection(.enabled)
                } header: {
                    Text("Server Response")
                }
            }
        }
        .listStyle(.insetGrouped)
        .alert("Error", isPresented: $errorShow){
            Button("OK".loc, action: {
            })
        } message: {
            Text(errorInfo)
        }
        .navigationTitle(viewModel.bundleID)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showAddCapability = true
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showAddCapability) {
            AddCapabilityView(viewModel: viewModel)
        }
    }
    
    func addCapability(_ id: String) async {
        do {
            try await viewModel.addCapability(id)
        } catch {
            errorInfo = error.localizedDescription
            errorShow = true
        }
    }
}

// MARK: - App ID row (LiveContainer-style banner with quick actions)

struct AppIDRow: View {
    @ObservedObject var model: AppIDModel
    var onQuickAction: (String) -> Void
    
    var body: some View {
        HStack(spacing: 14) {
            RoundedRectangle(cornerRadius: 10)
                .fill(LinearGradient(colors: [.blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 44, height: 44)
                .overlay(
                    Image(systemName: "app.badge.checkmark.fill")
                        .foregroundStyle(.white)
                        .font(.system(size: 19))
                )
            VStack(alignment: .leading, spacing: 2) {
                Text(model.bundleID)
                    .font(.body)
                    .lineLimit(1)
                Text("Tap to manage capabilities")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .contentShape(Rectangle())
        .contextMenu {
            ForEach(CapabilityCatalog.hidden) { capability in
                Button {
                    onQuickAction(capability.id)
                } label: {
                    Label("Add \(capability.label)", systemImage: capability.icon)
                }
            }
        }
    }
}

// MARK: - Main App IDs list

struct AppIDView : View {
    @StateObject var viewModel : AppIDViewModel
    
    @State private var errorShow = false
    @State private var errorInfo = ""
    @State private var searchText = ""
    
    private var filteredAppIDs: [AppIDModel] {
        guard !searchText.isEmpty else { return viewModel.appIDs }
        return viewModel.appIDs.filter {
            $0.bundleID.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    var body: some View {
        NavigationView {
            Group {
                if viewModel.appIDs.isEmpty {
                    emptyState
                } else {
                    List {
                        Section {
                            ForEach(filteredAppIDs, id: \.self) { appID in
                                NavigationLink {
                                    AppIDEditView(viewModel: appID)
                                } label: {
                                    AppIDRow(model: appID) { capabilityID in
                                        Task { await quickAdd(appID, capabilityID) }
                                    }
                                }
                            }
                        } header: {
                            Text("App IDs")
                        } footer: {
                            Text("Long-press an App ID to add a capability without opening it.")
                        }
                    }
                    .listStyle(.insetGrouped)
                    .searchable(text: $searchText, prompt: "Search App IDs")
                }
            }
            .navigationTitle("App IDs")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await refreshButtonClicked() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .alert("Error", isPresented: $errorShow){
                Button("OK".loc, action: {
                })
            } message: {
                Text(errorInfo)
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    private var emptyState: some View {
        VStack(spacing: 14) {
            RoundedRectangle(cornerRadius: 18)
                .fill(Color.secondary.opacity(0.15))
                .frame(width: 72, height: 72)
                .overlay(
                    Image(systemName: "square.stack.3d.up.slash")
                        .font(.system(size: 30))
                        .foregroundStyle(.secondary)
                )
            Text("No App IDs")
                .font(.headline)
            Text("Sign in and tap Refresh to load App IDs from your developer account.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button {
                Task { await refreshButtonClicked() }
            } label: {
                Label("Refresh", systemImage: "arrow.clockwise")
            }
            .buttonStyle(.bordered)
            .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    func refreshButtonClicked() async {
        do {
            try await viewModel.fetchAppIDs()
        } catch {
            errorInfo = error.localizedDescription
            errorShow = true
        }
    }
    
    func quickAdd(_ appID: AppIDModel, _ capabilityID: String) async {
        do {
            try await appID.addCapability(capabilityID)
        } catch {
            errorInfo = error.localizedDescription
            errorShow = true
        }
    }
}
