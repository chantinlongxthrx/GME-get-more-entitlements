//
//  AppIDViewModel.swift
//  Entitlement
//
//  Created by s s on 2025/3/15.
//
import SwiftUI
import StosSign

class AppIDModel : ObservableObject, Hashable {
    static func == (lhs: AppIDModel, rhs: AppIDModel) -> Bool {
        return lhs === rhs
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(ObjectIdentifier(self))
    }
    
    var appID: AppID
    @Published var bundleID: String
    @Published var result: String = ""
    
    init(appID: AppID) {
        self.appID = appID
        bundleID = appID.bundleIdentifier
    }
    
    private func buildHeaders(session: AppleAPISession) -> [String: String] {
        let dateFormatter = ISO8601DateFormatter()
        return [
            "Content-Type": "application/vnd.api+json",
            "User-Agent": "Xcode",
            "Accept": "application/vnd.api+json",
            "Accept-Language": "en-us",
            "X-Apple-App-Info": "com.apple.gs.xcode.auth",
            "X-Xcode-Version": "11.2 (11B41)",
            "X-Apple-I-Identity-Id": session.dsid,
            "X-Apple-GS-Token": session.authToken,
            "X-Apple-I-MD-M": session.anisetteData.machineID,
            "X-Apple-I-MD": session.anisetteData.oneTimePassword,
            "X-Apple-I-MD-LU": session.anisetteData.localUserID,
            "X-Apple-I-MD-RINFO": session.anisetteData.routingInfo.description,
            "X-Mme-Device-Id": session.anisetteData.deviceUniqueIdentifier,
            "X-MMe-Client-Info": session.anisetteData.deviceDescription,
            "X-Apple-I-Client-Time": dateFormatter.string(from: session.anisetteData.date),
            "X-Apple-Locale": session.anisetteData.locale.identifier,
            "X-Apple-I-TimeZone": session.anisetteData.timeZone.abbreviation()!
        ]
    }
    
    /// Adds a single bundle ID capability by its Apple Developer Services
    /// capability identifier (e.g. "INCREASED_MEMORY_LIMIT",
    /// "EXTENDED_VIRTUAL_ADDRESSING"). Add new entitlements by calling this
    /// with the right ID — no need to duplicate the request-building code.
    func addCapability(_ capabilityID: String) async throws {
        guard DataManager.shared.model.team != nil, let session = DataManager.shared.model.session else {
            throw "Please Login First"
        }

        let body: [String: Any] = [
            "data": [
                "relationships": [
                    "bundleIdCapabilities": [
                        "data": [
                            [
                                "relationships": [
                                    "capability": [
                                        "data": [
                                            "id": capabilityID,
                                            "type": "capabilities"
                                        ]
                                    ]
                                ],
                                "type": "bundleIdCapabilities"
                            ]
                        ]
                    ]
                ],
                "id": appID.identifier,
                "type": "bundleIds"
            ]
        ]

        let jsonData = try JSONSerialization.data(withJSONObject: body)

        var request = URLRequest(url: URL(string: "https://developerservices2.apple.com/services/v1/bundleIds/\(appID.identifier)")!)
        request.httpMethod = "PATCH"
        request.allHTTPHeaderFields = buildHeaders(session: session)
        request.httpBody = jsonData

        let (data, _) = try await URLSession.shared.data(for: request)

        await MainActor.run {
            result = String(data: data, encoding: .utf8) ?? "Unable to decode response."
        }
    }

    func addIncreasedMemory() async throws {
        try await addCapability("INCREASED_MEMORY_LIMIT")
    }

    func addExtendedVirtualAddressing() async throws {
        try await addCapability("EXTENDED_VIRTUAL_ADDRESSING")
    }
}

class AppIDViewModel : ObservableObject {
    @Published var appIDs : [AppIDModel] = []
    
    func fetchAppIDs() async throws {
        guard let team = DataManager.shared.model.team, let session = DataManager.shared.model.session else {
            throw "Please Login First"
        }
        
        let ids = try await withUnsafeThrowingContinuation { (c: UnsafeContinuation<[AppID], Error>) in
            AppleAPI().fetchAppIDsForTeam(team: team, session: session) { (appIDs, error) in
                if let error = appIDs as? Error {
                    c.resume(throwing: error)
                }
                guard let appIDs else {
                    c.resume(throwing: "AppIDs is nil. Please try again or reopen the app.")
                    return
                }
                c.resume(returning: appIDs)
            }
        }
        await MainActor.run {
            for id in ids {
                appIDs.append(AppIDModel(appID: id))
            }
        }
    }
}
